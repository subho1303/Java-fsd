package com.javapoint.springbooth2databaseexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootH2DatabaseExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
