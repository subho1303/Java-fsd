package practice;

public class D02P04 {
	public static void main(String[] args) {
		int arr[]=new int[3];
		try 
		{
			arr[7]=6;
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("The array index is out of bound");
		}
		finally
		{
			System.out.println("The size of the array is: "+arr.length);
		}
		
	}

}
