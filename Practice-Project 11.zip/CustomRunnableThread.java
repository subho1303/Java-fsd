package practice;

public class CustomRunnableThread implements Runnable {

    public static int count = 0;

    public CustomRunnableThread() {

    }

    public void run() {
        while (CustomRunnableThread.count <= 10) {
            try {
                System.out.println("Thread from Runnable: " + (++CustomRunnableThread.count));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in thread: " + iex.getMessage());
            }
        }
    }

    public static void main(String a[]) {
        System.out.println("Starting Main Thread...");
        CustomRunnableThread threadInstance = new CustomRunnableThread();
        Thread t = new Thread(threadInstance);
        t.start();
        while (CustomRunnableThread.count <= 10) {
            try {
                System.out.println("Main Thread: " + (++CustomRunnableThread.count));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in main thread: " + iex.getMessage());
            }
        }
        System.out.println("End of Main Thread...");
    }
}

