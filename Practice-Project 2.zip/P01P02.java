package practice;

class firstclass {
	public String publicfield="This ia public";
	private String privatefield="This is private";
	protected String protectedfield="This is protected";
	public void callfields()
	{
		System.out.println(publicfield);
		System.out.println(privatefield);
		System.out.println(protectedfield);
		
	}
	
}
	class subclass extends firstclass
	{
		public void printfields()
		{
			System.out.println(publicfield);
			System.out.println(protectedfield);
		}private void privatemethod() 
		{
			System.out.println("This is a private method");
		}
		protected void protectedmethod()
		{
			System.out.println("This is a protected method");
			
		}
		
	}
	public class P01P02
	{
		public static void main(String[] args) {
			 firstclass obj=new firstclass();
			 obj.callfields();
			 subclass sub=new subclass();
			 sub.protectedmethod();
			 
		}
}
	
