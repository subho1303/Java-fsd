package practice;

public class P01P07 {

	private  String text="Hello World";
	class Inner
	{
		void display()
		{
			System.out.println(text+"Let's start");
		}
	}
	public class innerclass1
	{
		void display()
		{
			class Inner
			{
				void msg()
				{
					System.out.println("Let's explore");
				}
			}
			Inner i=new Inner();
			i.msg();
		}
	}
	abstract class AnonymousInnerClass
	{
		abstract void display();
	}

	public static void main(String[] args) {
		P01P07 obj=new P01P07();
		P01P07.Inner i=obj.new Inner();
		i.display();
		innerclass1 obj1=obj.new innerclass1();
		obj1.display();
		AnonymousInnerClass obj2=obj.new AnonymousInnerClass() {
			public void display()
			{
			System.out.println("hello");
			}
		};
		obj2.display();
	}
}

