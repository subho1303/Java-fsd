package practice;

public class Students {
    private String name;
    private int rollNumber;
    private int age;

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }

    public int getRollNumber() {
        return rollNumber;
    }

    public void setAge(int newAge) {
        age = newAge;
    }

    public void setName(String newName) {
        name = newName;
    }

    public void setRollNumber(int newRollNumber) {
        rollNumber = newRollNumber;
    }
}

class TestEncapsulation {
    public static void main(String[] args) {
        Students student = new Students();
        student.setName("John");
        student.setAge(20);
        student.setRollNumber(101);
        System.out.println("Name: " + student.getName());
        System.out.println("Age: " + student.getAge());
        System.out.println("Roll Number: " + student.getRollNumber());
    }
}

