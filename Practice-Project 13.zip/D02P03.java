package practice;

import java.io.*; 
import java.util.*; 

class Sender {
    public void send(String msg) {
        System.out.println("Sending message: "  + msg ); 
        try { 
            Thread.sleep(1000); 
        } catch (InterruptedException e) { 
            System.out.println("Thread interrupted."); 
        } 
        System.out.println(msg + " sent successfully"); 
    } 
} 

class ThreadedSend extends Thread {
    private String msg; 
    private Sender sender; 

    ThreadedSend(String msg, Sender sender) { 
        this.msg = msg; 
        this.sender = sender; 
    } 
  
    public void run() {  
        synchronized(sender) { 
            sender.send(msg); 
        } 
    } 
} 

public class D02P03 {
    public static void main(String args[]) {
        Sender sender = new Sender(); 
        ThreadedSend S1 = new ThreadedSend("Hello", sender); 
        ThreadedSend S2 = new ThreadedSend("World", sender); 
        S1.start(); 
        S2.start(); 
        try { 
            S1.join(); 
            S2.join(); 
        } catch (InterruptedException e) { 
            System.out.println("Main thread interrupted."); 
        } 
    } 
} 

