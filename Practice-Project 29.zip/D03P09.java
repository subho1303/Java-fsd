package practice;

import java.util.LinkedList;
import java.util.Queue;

public class D03P09 {
    public static void main(String[] args) {
        Queue<String> Queues = new LinkedList<>();

        Queues.add("Kolkata");
        Queues.add("Dibrugarh");
        Queues.add("Chennai");
        Queues.add("Bangalore");
        System.out.println("Queue after insertion: " + Queues);

        Queues.remove("Chennai");
        

        System.out.println("Queue after removal: " + Queues);

        String frontElement = Queues.peek();
        System.out.println("Front element of the queue: " + frontElement);
    }
}

