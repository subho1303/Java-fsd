package practice;

import java.util.Scanner;

public class D04P04 {  
    public static void selectionSort(int[] arr){  
        for (int i = 0; i < arr.length - 1; i++) {  
            int index = i;  
            for (int j = i + 1; j < arr.length; j++) {  
                if (arr[j] < arr[index]) {  
                    index = j;
                }  
            }  
            int smallerNumber = arr[index];   
            arr[index] = arr[i];  
            arr[i] = smallerNumber;  
        }  
    }  
       
    public static void main(String a[]) {  
    	Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of the array: ");
        int size=sc.nextInt();
        int arr[]=new int[size];
        System.out.println("Enter the elements in the array: ");
        for(int i=0;i<arr.length;i++)
        {
        	arr[i]=sc.nextInt();
        }
        System.out.println("Before Selection Sort");  
        for (int i : arr) {  
            System.out.print(i + " ");  
        }  
        System.out.println();  
          
        selectionSort(arr);  // Sorting array using selection sort  
         
        System.out.println("After Selection Sort");  
        for (int i : arr) {  
            System.out.print(i + " ");  
        }  
    }  
}
