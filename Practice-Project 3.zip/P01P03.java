package practice;

public class P01P03 {
	public void multiply(int a,int b)
	{
		int ans=a*b;
		System.out.println("The answer is : "+ans);
	}
	int val=10;
	void operation(int val)
	{
		val=val*10;
		System.out.println(val);
	}
	public void area(int h,int b)
	{
		System.out.println("Area of the :"+(0.5)*h*b);
	}
	public void area(int r)
	{
		System.out.println("The radius of the circle is :"+3.14*r*r);
	}
	public static void main(String[] args) {
		P01P03 obj=new P01P03();
		obj.multiply(5, 5);
		obj.operation(20);
		obj.area(2, 3);
		obj.area(2);
		
		
	}

}
