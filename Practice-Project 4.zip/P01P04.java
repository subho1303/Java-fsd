package practice;

	class employee{
		String name;
		int id;
		void display()
		{
			System.out.println("The details are:"+name+" "+id);
		}
	}
	class employee1{
		String name;
		int id;
		void employee(String n,int i)
		{
			name=n;
			id=i;
		}
			void display()
			{
				System.out.println("The details are:"+name+""+id);
			}
		}
	public class P01P04 
	{
	public static void main(String[] args) {
		employee obj=new employee();
		obj.display();
		employee1 obj1=new employee1();
		obj1.employee("Rajat", 2023);
		obj1.display();	
	}
	}

