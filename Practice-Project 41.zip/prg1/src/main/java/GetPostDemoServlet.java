import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/getpostdemo")
public class GetPostDemoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>GET Request Demo</title></head>");
        out.println("<body>");
        out.println("<h1>GET Request Demo</h1>");
        String name = request.getParameter("name");
        if (name != null && !name.isEmpty()) {
            out.println("<p>Hello, " + name + "! This is a GET request.</p>");
        } else {
            out.println("<p>No name parameter found in GET request.</p>");
        }
        out.println("</body></html>");
    }
	 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<html><head><title>POST Request Demo</title></head>");
	        out.println("<body>");
	        out.println("<h1>POST Request Demo</h1>");
	        String name = request.getParameter("name");
	        if (name != null && !name.isEmpty()) {
	            out.println("<p>Hello, " + name + "! This is a POST request.</p>");
	        } else {
	            out.println("<p>No name parameter found in POST request.</p>");
	        }
	        out.println("</body></html>");
	    }
	}
