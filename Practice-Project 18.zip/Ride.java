package practice;

class Bicycle {
    public int gear;
    public int speed;

    public Bicycle(int gear, int speed) {
        this.gear = gear;
        this.speed = speed;
    }

    public void applyBrake(int decrement) {
        speed -= decrement;
    }

    public void speedUp(int increment) {
        speed += increment;
    }

    public String toString() {
        return "Number of gears: " + gear + "\nSpeed of bicycle: " + speed;
    }
}

class MountainBike extends Bicycle {
    public int seatHeight;

    public MountainBike(int gear, int speed, int startHeight) {
        super(gear, speed);
        seatHeight = startHeight;
    }

    public void setHeight(int newValue) {
        seatHeight = newValue;
    }

    @Override
    public String toString() {
        return super.toString() + "\nSeat height is " + seatHeight;
    }
}

public class Ride {
    public static void main(String args[]) {
        MountainBike mountainBike = new MountainBike(6, 100, 20);
        System.out.println(mountainBike.toString());
    }
}

