package practice;

class MyException extends Exception {
	  private String errorMessage; 

	  public MyException(String errorMessage) {
	    this.errorMessage = errorMessage;
	  }

	  @Override
	  public String toString() {
	    return "MyException Occurred: " + errorMessage;
	  }
	}

	class D02P06 {
	  public static void main(String args[]) {
	    try {
	      System.out.println("Starting of try block");
	      throw new MyException("Error occurred while processing data.");
	    } catch (MyException exp) {
	      System.out.println("Catch Block");
	      System.out.println(exp); 
	    }
	  }
	}