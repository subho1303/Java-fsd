package practice;

public class P01P01 {
	public static void main(String[] args) {
		System.out.println("Different types of typecasting");
		System.out.println("Implicit Typecasting");
		byte b=12;
		double d=b;
		System.out.println("double value:"+d);
		short s=b;
		System.out.println("short value:"+s);
		long l=b;
		System.out.println("long value:"+l);
		float f=b;
		System.out.println("float value:"+f);
		
		System.out.println("Explicit Typecasting");
		float y=5.6f;
		int i=(int)f;
		System.out.println("Value of y:"+y);
		System.out.println("Value of i:"+i);
		
	}

}
