package practice;

interface InterfaceA {
    default void display() {
        System.out.println("Default method in InterfaceA");
    }
}

interface InterfaceB {
    default void display() {
        System.out.println("Default method in InterfaceB");
    }
}

public class D02P09 implements InterfaceA, InterfaceB {
    public void display() {
        InterfaceA.super.display();
        InterfaceB.super.display();
    }

    public static void main(String args[]) {
        D02P09 obj = new D02P09();
        obj.display();
    }
}

