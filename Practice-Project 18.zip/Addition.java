package practice;

public class Addition {
    public int add(int a, int b) {
        return a + b;
    }

    public int add(int a, int b, int c) {
        return a + b + c;
    }

    public double add(double a, double b) {
        return a + b;
    }

    public static void main(String args[]) {
        Addition Addition = new Addition();
        System.out.println("Addition of 10 and 20: " + Addition.add(15, 10));
        System.out.println("Addition of 10, 20, and 30: " + Addition.add(20, 25, 30));
        System.out.println("Addition of 10.5 and 20.5: " + Addition.add(10.0, 40.5));
    }
}
