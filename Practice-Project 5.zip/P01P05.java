package practice;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Vector;

public class P01P05 {
	public static void main(String[] args) {
		System.out.println("Array");
		ArrayList<String> names=new ArrayList<>();
		names.add("Rahul");
		names.add("Vinod");
		System.out.println(names);
		System.out.println("Vector");
		Vector<String> student=new Vector();
		student.add("Kashsish");
		student.add("Amlan");
		System.out.println(student);
		System.out.println("Linked List");
		LinkedList<Integer> numbers=new LinkedList<Integer>();
		numbers.add(24);
		numbers.add(32);
		Iterator<Integer> itr=numbers.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("Hash Set");
		HashSet<String> places=new HashSet<>();
		places.add("Bangalore");
		places.add("Mumbai");
		Iterator<String> i=places.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		System.out.println("Linked Hash Set");
		LinkedHashSet<Integer> set=new LinkedHashSet<Integer>();
		set.add(55);
		set.add(45);
		set.add(66);
		set.add(11);
		System.out.println(set);
		
	}
}
