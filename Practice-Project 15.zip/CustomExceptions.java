package practice;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class CustomExceptions {
    public static void main(String[] args) {
        try {
            throw new CustomException("Custom Exception Message");
        } catch (CustomException ex) {
            System.out.println("Caught Custom Exception");
            System.out.println(ex.getMessage());
        }
    }
}

