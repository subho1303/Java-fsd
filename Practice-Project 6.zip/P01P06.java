package practice;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class P01P06 {
	public static void main(String[] args) {
		System.out.println("Hash Map");
		HashMap<Integer,String> std=new HashMap<>();
		std.put(1, "Pablo");
		std.put(2, "Rohan");
		for(Map.Entry m:std.entrySet())
		{
		System.out.println(m.getKey()+" "+m.getValue());
		}
		System.out.println("Hash Table");
		Hashtable<Integer,String> std1=new Hashtable<>();
		std1.put(3, "Ajay");
		std1.put(4, "John");
		for(Map.Entry n:std1.entrySet())
		{
			System.out.println(n.getKey()+" "+n.getValue());
		} 
		System.out.println("Tree Map");
		TreeMap<Integer,String> std2=new TreeMap<>();
		std2.put(5, "Joey");
		std2.put(6, "Ross");
		for(Map.Entry t:std2.entrySet() )
		{
			System.out.println(t.getKey()+" "+t.getValue());
		}
	}

}
