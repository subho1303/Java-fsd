package practice;

import java.util.Scanner;

class D04P02 {  
    public static void binarySearch(int arr[], int first, int last, int key) {  
        int mid = (first + last) / 2;  
        while (first <= last)
        {  
            if (arr[mid] < key)
            {  
                first = mid + 1;     
            }
            else if (arr[mid] == key)
            {  
                System.out.println("Element is found at index: " + mid);  
                break;  
            }
            else
            {  
                last = mid - 1;  
            }  
            mid = (first + last) / 2;  
        }  
        if (first > last)
        {  
            System.out.println("Element is not found!");  
        }  
    }  

    public static void main(String args[])
    {  
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of the array: ");
        int size=sc.nextInt();
        int arr[]=new int[size];
        System.out.println("Enter the elements in the array: ");
        for(int i=0;i<arr.length;i++)
        {
        	arr[i]=sc.nextInt();
        }
        System.out.println("Enter the element you want to search: ");
        int key = sc.nextInt();  
        int last = arr.length - 1;  
        binarySearch(arr, 0, last, key);     
    }  
}  

