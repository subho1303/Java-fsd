package practice;

public class P01P09 {
	public static void main(String[] args) {
		int a[]= {1,2,3,4,5};
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		System.out.println("----------------------------");
		System.out.println("Multidimensional Array");
		int b[][]= {
				{2,3,4,5,6},
				{7,8,9,10}
		};
		for(int i=0;i<b.length;i++)
		{
			for(int j=0;j<b[i].length;j++)
			{
				System.out.print(b[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("The length of row 1 is "+b[0].length);
	}
}
