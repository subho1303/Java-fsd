package practice;

public class D03P06 {
    static class Node {
        int data;
        Node next;

        Node(int d) {
            data = d;
            next = null;
        }
    }

    static Node insert(Node head, int data) {
        Node newNode = new Node(data);
        Node current = head;

        if (head == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (head.data >= newNode.data) {
            while (current.next != head)
                current = current.next;
            current.next = newNode;
            newNode.next = head;
            head = newNode;
        } else {
            while (current.next != head && current.next.data < newNode.data)
                current = current.next;
            newNode.next = current.next;
            current.next = newNode;
        }

        return head;
    }

    static void printList(Node head) {
        if (head != null) {
            Node temp = head;
            do {
                System.out.print(temp.data + " ");
                temp = temp.next;
            } while (temp != head);
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Node head = null;
        head = insert(head, 5);
        head = insert(head, 2);
        head = insert(head, 10);
        head = insert(head, 1);
        System.out.println("Sorted Circular Linked List:");
        printList(head);
    }
}
