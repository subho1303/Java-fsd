package practice;

public class P01P08 {
	public static void main(String[] args) {
		String s="Welcome";
		System.out.println(s.length());
		
		String s1="bye";
		System.out.println(s1.substring(2));
		
		String s2="Beautiful";
		String s3="Beautiful";
		System.out.println(s2.compareTo(s3));
		
		String s4="";
		System.out.println(s4.isEmpty());
		
		String s5="pahul";
		System.out.println(s5.replace('p', 'r'));
		
		String s6="home";
		System.out.println(s6.toUpperCase());
		
		String s7="HousE";
		System.out.println(s7.toLowerCase());
		
		String s8="Beautiful";
		String s9="Beautiful";
		System.out.println(s8.equals(s9));
		
		System.out.println("-------------------------------");
		System.out.println("String Buffer");
		StringBuffer stb=new StringBuffer("Welcome to ");
		stb.append("world of fun");
		System.out.println(stb);
		
		StringBuffer stb1=new StringBuffer("Home");
		stb1.replace(0, 2, "hoM");
		System.out.println(stb1);
		
		stb1.delete(0, 2);
		System.out.println(stb1);
		
		stb1.insert(0, 'h');
		System.out.println(stb1);
		
		System.out.println("-------------------------------");
		System.out.println("String Builder");
		StringBuilder sbd=new StringBuilder("Welcome ");
		sbd.append("Home");
		System.out.println(sbd);
		sbd.replace(0, 8, "Goodbye ");
		System.out.println(sbd);
		sbd.insert(8, "sweet ");
		System.out.println(sbd);
		System.out.println(sbd.reverse());
		
		String p="Hello";
		
		StringBuffer sbr1=new StringBuffer(p);
		sbr1.reverse();
		System.out.println("String to String Buffer");
		System.out.println(sbr1);
		
		StringBuilder sbd1=new StringBuilder(p);
		sbd1.append("Everyone");
		System.out.println("String to String Builder");
		System.out.println(sbd1);
		
	}

}
